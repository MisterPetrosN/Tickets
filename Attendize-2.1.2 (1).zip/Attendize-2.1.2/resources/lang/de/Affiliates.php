<?php
/*************************************************************************
 Generated via "php artisan localization:missing" at 2018/04/19 17:14:11 
*************************************************************************/

return array (
  //============================== New strings to translate ==============================//
  'affiliate_name' => 'Affiliate Name',
  'affiliate_tracking' => 'Affiliate Tracking',
  'affiliate_tracking_text' => 'Den Überblick darüber zu behalten, wer Verkäufe für Ihr Event generiert ist extrem einfach. Generieren Sie einfach einen Reflink und teilen Sie diesen mit Ihren Promotern oder Werbepartnern.',
  'last_referral' => 'Letzer Referral',
  'no_affiliate_referrals_yet' => 'Noch keine Affiliate Referrals',
  'sales_volume_generated' => 'Verkaufsvolumen generiert',
  'ticket_sales_generated' => 'Ticketverkäufe generiert',
  'visits_generated' => 'Besuche Generiert',
);