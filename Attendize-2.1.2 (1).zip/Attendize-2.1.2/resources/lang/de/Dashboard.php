<?php
/*************************************************************************
 Generated via "php artisan localization:missing" at 2018/04/19 18:57:21 
*************************************************************************/

return array (
    //============================== New strings to translate ==============================//
    'this_event_has_started' => 'Das Event hat begonnen.',
    //==================================== Translations ====================================//
    'create_tickets' => 'Tickets erstellen',
    'edit_event_page_design' => 'Eventseitendesign bearbeiten',
    'edit_organiser_fees' => 'Veranstaltergebühren bearbeiten',
    'event_page_visits' => 'Eventseitenbesucher',
    'event_url' => 'Event URL',
    'event_views' => 'Event Besucher',
    'generate_affiliate_link' => 'Affiliate link erstellen',
    'orders' => 'Bestellungen',
    'quick_links' => 'Quick Links',
    'registrations_by_ticket' => 'Regestrierungen per Ticket',
    'sales_volume' => 'Verkaufsvolumen',
    'share_event' => 'Event teilen',
    'this_event_is_on_now' => 'Dieses Event findet gerade Statt',
    'ticket_sales_volume' => 'Ticket Verkaufs Volumen',
    'tickets_sold' => 'Tickets verkauft',
    'website_embed_code' => 'Webseiten einbindungs Code',
);