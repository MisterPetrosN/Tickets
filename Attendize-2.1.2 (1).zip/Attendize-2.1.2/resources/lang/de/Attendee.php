<?php
/*************************************************************************
 Generated via "php artisan localization:missing" at 2018/04/19 17:07:35
*************************************************************************/

return array (
  //============================== New strings to translate ==============================//
  'scan_another_ticket' => 'Ein anderes Ticket scannen',
  'scanning' => 'Scannen',
  //==================================== Translations ====================================//
  'attendees' => 'Teilnehmer',
  'check_in' => 'Check in: :event',
  'email' => 'Email',
  'email_address' => 'Email Addresse',
  'event_attendees' => 'Event Teilnehmer',
  'first_name' => 'Vorname',
  'last_name' => 'Nachname',
  'name' => 'Name',
  'ticket' => 'Ticket',
  'reference' => 'Referenz',
  'search_attendees' => 'Teilnehmersuche...',
  'send_invitation_n_ticket_to_attendee' => 'Einladung und Ticket an Teilnehmer senden.',
);
