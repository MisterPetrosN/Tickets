<?php
/*************************************************************************
 Generated via "php artisan localization:missing" at 2018/04/26 11:05:24 
*************************************************************************/

return array (
  //==================================== Translations ====================================//
  'attendize_register' => 'Danke das sie sich bei Attendize regestriert haben',
  'invite_user' => ':name hat Ihnen einen :app account erstellt.',
  'message_regarding_event' => 'Nachricht betreffend: :event',
  'organiser_copy' => '[Kopie für den Veranstalter]',
  'refund_from_name' => 'Sie haben eine Rückerstattung von :name erhalten',
  'your_ticket_cancelled' => 'Ihr Ticket wurde storniert',
  'your_ticket_for_event' => 'Ihr Ticket für die Veranstaltung :event',
    //================================== Obsolete strings ==================================//
  'LLH:obsolete' => 
  array (

  ),
);
