<?php

return array(
    'attendize_register'      => 'Attendizeに登録していただきありがとうございます',
    'invite_user'             => ':nameがあなたを:appアカウントに追加しました。',
    'message_regarding_event' => ':eventに関するメッセージ',
    'organiser_copy'          => '[主催者コピー]',
    'refund_from_name'        => 'あなたは:nameから払い戻しを受けました。',
    'your_ticket_cancelled'   => 'あなたのチケットはキャンセルされました',
    'your_ticket_for_event'   => 'イベント:eventのためのあなたのチケット。',
    //================================== Obsolete strings ==================================//
    'LLH:obsolete'            =>
        array(),
);
