<?php

return array(
    'scan_another_ticket'                  => '別のチケットをスキャン',
    'scanning'                             => 'スキャン中',
    'attendees'                            => '出席者',
    'check_in'                             => 'チェックイン：:event',
    'email'                                => 'Email',
    'email_address'                        => 'メールアドレス',
    'event_attendees'                      => 'イベント出席者',
    'first_name'                           => '名',
    'last_name'                            => '姓',
    'name'                                 => '名前',
    'ticket'                               => 'チケット',
    'reference'                            => '照合',
    'search_attendees'                     => '出席者の検索...',
    'send_invitation_n_ticket_to_attendee' => '招待状とチケットを出席者に送信します。',
);
