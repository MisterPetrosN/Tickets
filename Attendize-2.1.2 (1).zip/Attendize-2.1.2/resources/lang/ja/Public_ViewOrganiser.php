<?php

return array(
    //============================== New strings to translate ==============================//
    // Defined in file C:\\wamp\\www\\attendize\\resources\\views\\Public\\ViewOrganiser\\Partials\\EventListingPanel.blade.php
    'information'         => '情報',
    // Defined in file C:\\wamp\\www\\attendize\\resources\\views\\Public\\ViewOrganiser\\Partials\\EventListingPanel.blade.php
    'tickets'             => 'チケット',
    //==================================== Translations ====================================//
    'no_events'           => '表示する:panel_titleがありません。',
    'organiser_dashboard' => '主催者ダッシュボード',
    'past_events'         => '過去のイベント',
    'upcoming_events'     => '今後のイベント',
);