<?php

return array (
  //============================== New strings to translate ==============================//
  // Defined in file C:\\wamp\\www\\attendize\\resources\\views\\ManageEvent\\Surveys.blade.php
  'question_delete' => 'Question Supprimer',
  //==================================== Translations ====================================//
  'add_question' => 'Ajouter une question',
  'answers' => 'Réponses',
  'event_surveys' => 'Questionnaires de l\'événement',
  'export_answers' => 'Exporter les réponses',
  'num_responses' => '# Réponses',
  'question_delete_title' => 'Toutes les réponses seront aussi effacées. Si vous voulez garder les réponses du participant, vous devriez plutôt désactiver la question.',
  'question_title' => 'Titre de la question',
  'required' => 'Requis',
  'status' => 'Statut',
  'tickets_list' => 'Billets : :list',
);
