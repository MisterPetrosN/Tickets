<?php
/*************************************************************************
 Generated via "php artisan localization:missing" at 2018/04/19 17:14:11
*************************************************************************/

return array (
  //============================== New strings to translate ==============================//
  'affiliate_name' => 'Nom du partenaire',
  'affiliate_tracking' => 'Suivi du parrainage',
  'affiliate_tracking_text' => 'Il est très facile de suivre les ventes de tickets générées par chacun de vos partenaires. Il vous suffit d\'écrire ci-dessous pour générer automatiquement un lien de parrainage à partager avec vos partenaires et promoteurs d\'évènements.',
  'last_referral' => 'Dernier parrainage',
  'no_affiliate_referrals_yet' => 'Pas de partenaire',
  'sales_volume_generated' => 'Volume des ventes généré',
  'ticket_sales_generated' => 'Ventes de tickets générées',
  'visits_generated' => 'Visites générées',
);
