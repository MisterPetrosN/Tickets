<?php
/*************************************************************************
 Generated via "php artisan localization:missing" at 2018/04/26 11:05:24 
*************************************************************************/

return array (
  //==================================== Translations ====================================//
  'attendize_register' => 'Thank you for registering for Attendize',
  'invite_user' => ':name added you to an :app account.',
  'message_regarding_event' => 'Message Regarding: :event',
  'organiser_copy' => '[Organiser Copy]',
  'refund_from_name' => 'You have received a refund from :name',
  'your_ticket_cancelled' => 'Your ticket has been cancelled',
  'your_ticket_for_event' => 'Your ticket for the event :event',
    //================================== Obsolete strings ==================================//
  'LLH:obsolete' => 
  array (

  ),
);
