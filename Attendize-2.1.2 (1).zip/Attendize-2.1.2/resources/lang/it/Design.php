<?php

return [
    'event_page_preview' => 'Anteprima Pagina Evento',
    'background_options' => 'Opzioni sfondo',
    'images_provided_by_pixabay' => 'Immagini fornite da <b>PixaBay.com</b>',
    'select_from_available_images' => 'Seleziona dalle immagini disponibili',
    'use_a_colour_for_the_background' => 'Utilizzare un colore per lo sfondo',
];