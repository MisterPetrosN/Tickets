<?php

return [
    'back_soon' => 'Torneremo presto',
    'back_soon_description' => 'Manutenzione in corso',
];
