<?php

return [
    'create_question' => 'Crea domanda',
    'Q' => 'Q',
    'add_another_option' => 'Aggiungere un\'altra opzione',
    'answer' => 'Risposta',
    'attendee_details' => 'Dettagli dei partecipanti',
    'make_this_a_required_question' => 'Rendi quest\'opzione obbligatoria',
    'no_answers' => 'Siamo spiacenti, non ci sono risposte disponibili per questa domanda. ',
    'no_questions_yet' => 'Nessuna domanda',
    'no_questions_yet_text' => 'Qui è possibile aggiungere domande alle quali i partecipanti saranno invitati a rispondere durante il processo di checkout. ',
    'question' => 'Domanda',
    'question_options' => 'Opzioni della domanda',
    'question_placeholder' => 'Per esempio: Per favore inserisci il tuo indirizzo completo?',
    'question_type' => 'Tipo di domanda',
    'require_this_question_for_ticket(s)' => 'Rendi questa domanda obbligatoria per i biglietti',
];