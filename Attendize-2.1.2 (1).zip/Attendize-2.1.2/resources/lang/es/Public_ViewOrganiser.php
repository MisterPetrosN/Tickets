<?php

return array(
    'information'         => 'Información',
    'no_events'           => 'No hay ningún :panel_title para mostrar.',
    'organiser_dashboard' => 'Panel de control del organizador',
    'past_events'         => 'Eventos pasados',
    'tickets'             => 'Entradas',
    'upcoming_events'     => 'Próximos eventos',
);