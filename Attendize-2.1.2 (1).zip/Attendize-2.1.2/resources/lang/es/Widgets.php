<?php

return array(
    'embed_preview'     => 'Vista previa de incrustación',
    'event_widgets'     => 'Widgets del evento',
    'html_embed_code'   => 'Código HTML para incrustar',
    'instructions'      => 'Instrucciones',
    'instructions_text' => 'Simplemente copia y pega el HTML proporcionado en tu sitio web donde quieras que aparezca el widget.',
);