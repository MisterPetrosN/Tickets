<?php

return array(
    'email'                  => 'Correo electrónico',
    'facebook'               => 'Facebook',
    'g+'                     => 'Google+',
    'linkedin'               => 'LinkedIn',
    'pinterest'              => 'Pinterest',
    'share_buttons_to_show'  => 'Botones Compartir para mostrar',
    'social_settings'        => 'Configuración social',
    'social_share_text'      => 'Texto para compartir en redes sociales',
    'social_share_text_help' => 'Este es el texto que será compartido por defecto cuando un usuario comparta tu evento en las redes sociales.',
    'twitter'                => 'Twitter',
    'whatsapp'               => 'WhatsApp',
);